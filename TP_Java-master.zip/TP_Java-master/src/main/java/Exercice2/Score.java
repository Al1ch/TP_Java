package Exercice2;

public class Score {
    protected int score_1;
    protected int score_2;

    public Score(int score_1 , int score_2){
        this.score_1 = score_1;
        this.score_2 = score_2;
    }


}
